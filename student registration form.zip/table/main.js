//Sellections
var table = document.querySelector(".table");
var thead = document.querySelector(".thead");
var tbody = document.querySelector(".tbody");
var st_name = document.querySelector(".name");
var email = document.querySelector(".email");
var id = document.querySelector(".id");
var add_btn = document.querySelector(".add");
var erros_container = document.querySelector(".erros-container");


    // tbody.innerHTML += `
    // <tr>
    // <td>${data_id} </td>    
    // <td> ${data_name} </td>    
    // <td>${data_email}</td>     
    // <td><button class="deleteBtn">Remove</button></td>     
    // </tr>                        
    //         `
    // Add Button

    add_btn.addEventListener("click", (e) => {
        e.preventDefault();

        if (id.value !== "" && email.value !== "" && st_name.value !== "") {
            // if(id.value !== buttonID){
            // alert(`ID: ${id.value} already exists.`);
            // erros_container.style.opacity = 1;
            // setTimeout(() =>{

            //     erros_container.style.opacity = 0;
            // },3000)
            // erros_container.innerHTML = `ID: ${id.value} already exists, please try again!`
            // }else{  
            tbody.innerHTML += `
                    <tr>
                        <td>${id.value} </td>    
                        <td> ${st_name.value} </td>    
                        <td>${email.value}</td>     
                        <td><button class="deleteBtn">Remove</button></td>     
                    </tr>                        
                    `
        } else {
            // alert("please Fill out the entries!")
            erros_container.style.opacity = 1;
            setTimeout(() => {
                erros_container.style.opacity = 0;
            }, 3000)
            erros_container.innerHTML = `
                    <i class="fa-solid fa-triangle-exclamation"></i>
                    <p>please Fill out the entries!</p>
                    `
        } 
        id.value = "";
        st_name.value = "";
        email.value = "";
    })


    //  Delete Button

    table.addEventListener("click", (e) => {
        e.preventDefault();

        var target = e.target;
        if (target.classList == "deleteBtn") {
            //    console.log(target.parentNode.parentNode);
            // console.log(target.attributes.testid)
            target.parentNode.parentNode.remove();
            var buttonID = target.attributes.testid
            
            // storage.removeItem("name", target.attributes.testid)
            // storage.removeItem("email", target.attributes.testid)
            // storage.removeItem("id", target.attributes.testid)

        }

    })

